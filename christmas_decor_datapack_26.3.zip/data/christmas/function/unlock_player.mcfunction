recipe give @s *
tag @s add xmas_recipes_unlocked
