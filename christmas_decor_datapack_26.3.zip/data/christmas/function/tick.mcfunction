# Автоматическая обработка 3D-декораций каждый тик
# 1. Если рамка поставлена с тегом xmas_decor — сразу делаем её невидимой и кладём 3D-модель внутрь (установка в 1 клик!)
execute as @e[type=minecraft:glow_item_frame,tag=xmas_decor,tag=!xmas_placed] at @s run function christmas:init_frame

# 2. Если игрок в выживании без прав оператора поставил рамку и вставил туда новогодний предмет (с custom_data.xmas_id) — делаем рамку невидимой автоматически!
execute as @e[type=minecraft:glow_item_frame,tag=!xmas_placed] if data entity @s Item.components."minecraft:custom_data".xmas_id run function christmas:make_invisible
execute as @e[type=minecraft:item_frame,tag=!xmas_placed] if data entity @s Item.components."minecraft:custom_data".xmas_id run function christmas:make_invisible

# 3. Когда игрок ломает декорацию (ЛКМ) — предмет выпадает, а пустая невидимая рамка сразу удаляется
execute as @e[type=minecraft:glow_item_frame,tag=xmas_placed] unless data entity @s Item.id run kill @s
execute as @e[type=minecraft:item_frame,tag=xmas_placed] unless data entity @s Item.id run kill @s

# 4. Авто-разблокировка всех новогодних рецептов в книге рецептов для всех игроков на сервере
execute as @a[tag=!xmas_recipes_unlocked] run function christmas:unlock_player
