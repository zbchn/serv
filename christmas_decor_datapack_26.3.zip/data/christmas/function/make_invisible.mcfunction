data merge entity @s {Invisible:1b,Silent:1b}
tag @s add xmas_placed
