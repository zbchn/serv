tellraw @a [{"text":"[🎄 Новый Год] ","color":"green","bold":true},{"text":"Новогодние 3D-декорации и крафты загружены! Все рецепты доступны в книге рецептов на верстаке.","color":"white"}]
tag @a remove xmas_recipes_unlocked
